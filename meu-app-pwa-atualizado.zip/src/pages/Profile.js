export default function Profile() {
    return <h1>Perfil</h1>;
  }
  