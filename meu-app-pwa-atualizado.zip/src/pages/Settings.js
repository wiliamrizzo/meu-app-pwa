export default function Settings() {
  return <h1>Configurações</h1>;
}
