export default function About() {
  return <h1>Sobre o App</h1>;
}
