import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Profile from './pages/Profile';

function Home() {
  return <h1>Home</h1>;
}

function Profile() {
  return <h1>Perfil</h1>;
}

export default function App() {
  return (
    <Router>
      <div style={{ paddingBottom: '70px' /* espaço para o menu */ }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </div>

      <nav style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        height: '60px',
        backgroundColor: '#eee',
        display: 'flex',
        justifyContent: 'space-around',
        alignItems: 'center',
        borderTop: '1px solid #ccc',
        boxShadow: '0 -2px 5px rgba(0,0,0,0.1)'
      }}>
        <Link to="/">Home</Link>
        <Link to="/profile">Perfil</Link>
      </nav>
    </Router>
  );
}
